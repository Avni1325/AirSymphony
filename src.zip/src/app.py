from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, RoundedRectangle
from kivy.core.window import Window


Window.size = (400, 700)


class AirSymphonyScreen(FloatLayout):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)


        # Background

        with self.canvas.before:

            Color(
                0.05,
                0.05,
                0.08,
                1
            )

            self.bg = RoundedRectangle(
                pos=self.pos,
                size=self.size
            )


        self.bind(
            size=self.update_bg,
            pos=self.update_bg
        )


        # Title

        title = Label(
            text="[b][color=00d7ff]AIRSYMPHONY[/color][/b]",
            markup=True,
            font_size=38,
            pos_hint={
                "center_x":0.5,
                "top":0.85
            }
        )


        self.add_widget(title)



        subtitle = Label(
            text="Hand Controlled Music Experience",
            font_size=16,
            pos_hint={
                "center_x":0.5,
                "top":0.75
            }
        )


        self.add_widget(subtitle)



        # Start Button

        start = Button(
            text="START",
            size_hint=(0.5,0.08),
            pos_hint={
                "center_x":0.5,
                "center_y":0.2
            },
            background_color=(0,0.7,1,1)
        )


        start.bind(
            on_press=self.start_app
        )


        self.add_widget(start)



    def update_bg(self,*args):

        self.bg.pos = self.pos

        self.bg.size = self.size



    def start_app(self,button):

        button.text = "STARTING..."



class AirSymphonyApp(App):

    def build(self):

        return AirSymphonyScreen()



if __name__ == "__main__":

    AirSymphonyApp().run()