from kivy.graphics import Color, Line
from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.graphics.texture import Texture
from kivy.clock import Clock
from kivy.core.window import Window

import cv2

from handtracker import HandTracker
from gestures import GestureDetector
from audio import MusicController
from effects import StringEffect
from lyrics import Lyrics



Window.size = (420, 750)



class MusicScreen(FloatLayout):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)



        # Camera area

        self.camera_view = Image(
    size_hint=(1,0.78),
    pos_hint={
        "x":0,
        "top":0.98
    }
)
        self.add_widget(
            self.camera_view
        )
        # Visual wave overlay

with self.canvas.after:

    Color(
        1,
        0.8,
        0.2,
        0.8
    )

    self.wave = Line(
        points=[],
        width=2
    )



        # Song title area

    self.song_label = Label(
    text="♪ AirSymphony",
    font_size=18,
    pos_hint={
        "center_x":0.5,
        "y":0.12
    }
)

    self.add_widget(
            self.song_label
        )



        # Status

    self.label = Label(
            text="Show your hand",
            font_size=16,
            pos_hint={
                "center_x":0.5,
                "y":0.04
                }
        )

        self.add_widget(
            self.label
        )



        # Systems

        self.tracker = HandTracker(
            "models/hand_landmarker.task",
            max_hands=2
        )


        self.gesture = GestureDetector()


        self.music = MusicController(
            "songs"
        )


        self.lyrics = Lyrics()


        self.effects = StringEffect()



        self.cap = cv2.VideoCapture(0)


        Clock.schedule_interval(
            self.update,
            1/30
        )



    def update(self, dt):

        success, frame = self.cap.read()


        if not success:

            return



        # Remove mirror inversion

        frame = cv2.flip(
            frame,
            0
        )



        hands = self.tracker.find_hands(
            frame
        )



        if hands:

            self.label.text = "Hand detected 🎵"

        else:

            self.label.text = "Show your hand"



        # Convert camera frame

        frame = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )


        texture = Texture.create(
            size=(
                frame.shape[1],
                frame.shape[0]
            ),
            colorfmt="rgb"
        )


        texture.blit_buffer(
            frame.tobytes(),
            colorfmt="rgb",
            bufferfmt="ubyte"
        )


        self.camera_view.texture = texture




class IntroScreen(FloatLayout):


    def __init__(self, **kwargs):

        super().__init__(**kwargs)



        title = Label(
            text="[b][color=00d7ff]AIRSYMPHONY[/color][/b]",
            markup=True,
            font_size=38,
            size_hint=(1,0.15),
            pos_hint={
                "center_x":0.5,
                "top":0.85
            }
        )

        self.add_widget(
            title
        )



        subtitle = Label(
            text="Hand Controlled Music Experience",
            font_size=16,
            size_hint=(1,0.1),
            pos_hint={
                "center_x":0.5,
                "top":0.70
            }
        )


        self.add_widget(
            subtitle
        )



        instructions = Label(
            text=
            "RIGHT HAND\n"
            "Open Palm  → Play\n"
            "Fist       → Pause\n\n"
            "LEFT HAND\n"
            "Show Fingers → Change Songs",
            font_size=17,
            halign="center",
            valign="middle",
            size_hint=(1,0.35),
            pos_hint={
                "center_x":0.5,
                "center_y":0.45
            }
        )


        instructions.bind(
            size=instructions.setter("text_size")
        )


        self.add_widget(
            instructions
        )



        start = Button(
            text="START",
            size_hint=(0.45,0.08),
            pos_hint={
                "center_x":0.5,
                "center_y":0.12
            },
            background_color=(0,0.7,1,1)
        )


        start.bind(
            on_press=self.start
        )


        self.add_widget(
            start
        )



    def start(self,button):

        self.clear_widgets()

        self.add_widget(
            MusicScreen()
        )





class AirSymphonyApp(App):

    def build(self):

        return IntroScreen()



if __name__ == "__main__":

    AirSymphonyApp().run()